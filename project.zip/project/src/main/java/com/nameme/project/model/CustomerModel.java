package com.nameme.project.model;

public class CustomerModel {
	public int id;
	public String name;
	
}
