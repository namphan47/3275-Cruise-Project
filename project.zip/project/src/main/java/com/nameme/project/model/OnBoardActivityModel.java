package com.nameme.project.model;

public class OnBoardActivityModel extends ActivityModel {
	public String target;
}
