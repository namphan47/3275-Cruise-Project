package com.nameme.project.model;

public class PortOfCallActivity extends ActivityModel {
	@Override
	public double calculatePrice() {
		return 0;
	}
}
