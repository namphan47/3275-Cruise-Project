package com.nameme.project.model;

public class RoomTypeModel {
	public String name;
	public String description;
	public double basePrice;
}
