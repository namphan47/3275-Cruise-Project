package com.nameme.project.model;

import java.util.ArrayList;
import java.util.List;

public class CruiseModel {
	public String name;
	public List<RouteModel> routes = new ArrayList<RouteModel>();
}
